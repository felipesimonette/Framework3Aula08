import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service/service.service';

@Component({
  selector: 'app-componente',
  templateUrl: './componente.component.html',
  styleUrls: ['./componente.component.css']
})
export class ComponenteComponent implements OnInit {

  constructor(private ServiceService: ServiceService) { }

  ngOnInit(): void {
  }

 
  //#region Controle de visão
  exibirMenu(): boolean {
    return this.ServiceService.exibirMenu;
  }

  exibirAtendimento(): boolean {
    return this.ServiceService.exibirAtendimento;
  }

  exibirSituacaoFila(): boolean {
    return this.ServiceService.exibirSituacaoFila;
  }

  voltar(){
    this.ServiceService.showMenu();
  }

  resetar(): void {
    this.ServiceService.resetar();
  }

  //#endregion
  
  coletarExames(): void {
    this.ServiceService.coletarExames();
  }

  retirarResultados(): void {
    this.ServiceService.retirarResultados();
  }

  filaPrioritaria(): void {
    this.ServiceService.prioritario();
  }

  administracao(): Array<any> {
    return this.ServiceService.situacaoGeral();
  }

  exibirTipoDeAtendimento(): string {
    return this.ServiceService.tipoAtendimento;
  }

  exibirPosicaoNaFila(): number {
    return this.ServiceService.posicaoAtual;
  }

}